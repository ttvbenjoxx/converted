/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/pages/SaveUps.tsx */

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Home } from "lucide-react";
import { useStore } from "@/lib/store";
import { SaveUpsList } from "@/components/save-ups/SaveUpsList";
import { AutoDepositDisplay } from "@/components/save-ups/AutoDepositDisplay";
import { AddSaveUpModal } from "@/components/modals/AddSaveUpModal";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const SaveUps = () => {
  const { balances, saveUps } = useStore();
  const [addModalOpen, setAddModalOpen] = useState(false);
  const navigate = useNavigate();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const hasAutoDeposits = saveUps.some(item => item.autoDeposit.enabled);

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl md:text-4xl font-bold text-foreground">Save-Ups</h1>
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/')}
          className="text-foreground"
        >
          <Home className="h-5 w-5" />
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-card border-border p-6">
          <h2 className="text-foreground mb-2">Account Total Balance (ATB)</h2>
          <p className="text-4xl md:text-6xl font-bold text-primary">
            {formatCurrency(balances.atb)}
          </p>
        </Card>

        <Card className="bg-card border-border p-6">
          <h2 className="text-foreground mb-2">Spending Money</h2>
          <p className="text-4xl md:text-6xl font-bold text-primary">
            {formatCurrency(balances.misc)}
          </p>
        </Card>
      </div>

      <div className="flex items-center gap-4 mb-8">
        <Button 
          onClick={() => setAddModalOpen(true)}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Save-Up
        </Button>

        {hasAutoDeposits && <AutoDepositDisplay />}
      </div>

      <SaveUpsList />

      <AddSaveUpModal
        open={addModalOpen}
        onOpenChange={setAddModalOpen}
      />
    </div>
  );
};

export default SaveUps;
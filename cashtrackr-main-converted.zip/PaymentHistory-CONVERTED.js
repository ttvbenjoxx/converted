/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/ReimbursementDetailsModal/PaymentHistory.tsx */

import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";

interface PaymentHistoryProps {
  payments: { amount: number; date: string }[];
  remainingBalance?: number;
}

export function PaymentHistory({ payments, remainingBalance }: PaymentHistoryProps) {
  return (
    <div className="space-y-2">
      <Label className="text-white">Payment History</Label>
      <ScrollArea className="h-[100px] rounded-md border border-border p-2 bg-card">
        <div className="space-y-1">
          {payments.map((payment, index) => (
            <div key={index} className="text-sm text-white">
              {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
              }).format(payment.amount)} on {new Date(payment.date).toLocaleDateString()}
            </div>
          ))}
        </div>
      </ScrollArea>
      {remainingBalance && remainingBalance > 0 && (
        <p className="text-sm font-medium text-destructive">
          Remaining Balance: {new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
          }).format(remainingBalance)}
        </p>
      )}
    </div>
  );
}
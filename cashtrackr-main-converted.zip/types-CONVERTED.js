/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/lib/store/types.ts */

import { Balances, Transaction, Reimbursement, Calculations, Paycheck, SaveUpItem } from '../types';

export interface Store {
  balances: Balances;
  transactions: Transaction[];
  reimbursements: Reimbursement[];
  paychecks: Paycheck[];
  calculations: Calculations;
  saveUps: SaveUpItem[];
  updateBalances: (newBalances: Partial<Balances>) => void;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
  addReimbursement: (reimbursement: Omit<Reimbursement, 'id' | 'date'>) => void;
  updateReimbursements: (reimbursements: Reimbursement[]) => void;
  addPaycheck: (paycheck: Omit<Paycheck, 'id' | 'date'>) => void;
  updateCalculations: (newCalculations: Partial<Calculations>) => void;
  resetAll: () => void;
  addSaveUp: (item: Omit<SaveUpItem, 'id' | 'saved' | 'deposits'>) => void;
  updateSaveUp: (id: string, updates: Partial<SaveUpItem>) => void;
  deleteSaveUp: (id: string) => void;
  addDeposit: (saveUpId: string, amount: number, details?: string) => void;
}
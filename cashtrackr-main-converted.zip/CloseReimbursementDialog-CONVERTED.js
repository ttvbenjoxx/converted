/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/ReimbursementDetailsModal/CloseReimbursementDialog.tsx */

import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface CloseReimbursementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  expectedAmount: number;
  actualPayment: string;
  setActualPayment: (value: string) => void;
  onProcess: () => void;
}

export function CloseReimbursementDialog({
  open,
  onOpenChange,
  expectedAmount,
  actualPayment,
  setActualPayment,
  onProcess
}: CloseReimbursementDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-card border border-border">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-white">Close Reimbursement</AlertDialogTitle>
          <AlertDialogDescription className="text-white">
            Expected amount: {new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD'
            }).format(expectedAmount)}
            <div className="mt-4">
              <Label className="text-white">Enter actual payment received</Label>
              <Input
                type="number"
                value={actualPayment}
                onChange={(e) => setActualPayment(e.target.value)}
                className="mt-2 text-white bg-card"
              />
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="bg-secondary text-white">Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onProcess} className="bg-primary text-white">
            Process Payment
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
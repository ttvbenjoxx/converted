/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/AddSaveUpModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";

interface AddSaveUpModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddSaveUpModal({ open, onOpenChange }: AddSaveUpModalProps) {
  const { addSaveUp } = useStore();
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [link, setLink] = useState("");
  const [details, setDetails] = useState("");

  const handleSubmit = () => {
    if (!name || !price) {
      toast.error("Please fill in all required fields");
      return;
    }

    const priceNum = Number(price);
    if (isNaN(priceNum) || priceNum <= 0) {
      toast.error("Please enter a valid price");
      return;
    }

    addSaveUp({
      name,
      price: priceNum,
      link,
      details,
      autoDeposit: {
        enabled: false,
        amount: 0,
      },
    });

    toast.success("Save-Up added successfully");
    onOpenChange(false);
    setName("");
    setPrice("");
    setLink("");
    setDetails("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-white">Add New Save-Up</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Name *</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter item name"
            />
          </div>
          <div className="space-y-2">
            <Label>Price *</Label>
            <Input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Enter price"
            />
          </div>
          <div className="space-y-2">
            <Label>Link (optional)</Label>
            <Input
              value={link}
              onChange={(e) => setLink(e.target.value)}
              placeholder="Enter item link"
            />
          </div>
          <div className="space-y-2">
            <Label>Details (optional)</Label>
            <Textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="Enter additional details"
            />
          </div>
        </div>
        <Button onClick={handleSubmit} className="w-full">
          Add Save-Up
        </Button>
      </DialogContent>
    </Dialog>
  );
}
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/DeleteSaveUpModal.tsx */

import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";
import { SaveUpItem } from "@/lib/types";

interface DeleteSaveUpModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saveUp: SaveUpItem;
}

export function DeleteSaveUpModal({ open, onOpenChange, saveUp }: DeleteSaveUpModalProps) {
  const { deleteSaveUp } = useStore();
  const [deleteText, setDeleteText] = useState("");
  const [priceConfirm, setPriceConfirm] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const isDeleteValid = () => {
    return deleteText === "Delete" && 
           priceConfirm === saveUp.price.toString() && 
           confirmDelete;
  };

  const handleDelete = () => {
    if (!isDeleteValid()) {
      toast.error("Please fill in all fields correctly");
      return;
    }
    deleteSaveUp(saveUp.id);
    onOpenChange(false);
    toast.success(`${saveUp.name} has been deleted`);
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-[#1A1F2C]">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-white">Delete {saveUp.name}</AlertDialogTitle>
          <AlertDialogDescription className="text-gray-300">
            This action is irreversible. Please type "Delete" to confirm.
            <Input
              value={deleteText}
              onChange={(e) => setDeleteText(e.target.value)}
              className="mt-2 dark-input"
              placeholder='Type "Delete"'
            />
            <div className="mt-4">
              <Label className="text-white">Item Price: {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
              }).format(saveUp.price)}</Label>
              <Input
                type="text"
                value={priceConfirm}
                onChange={(e) => setPriceConfirm(e.target.value)}
                className="mt-2 dark-input"
                placeholder="Enter item price"
              />
            </div>
            <div className="flex items-center space-x-2 mt-4">
              <Checkbox
                id="confirm-delete"
                checked={confirmDelete}
                onCheckedChange={(checked) => setConfirmDelete(checked as boolean)}
              />
              <label
                htmlFor="confirm-delete"
                className="text-white text-sm font-medium leading-none"
              >
                I understand that this will permanently delete this Save-Up
              </label>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="text-white">Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={handleDelete}
            disabled={!isDeleteValid()}
            className={!isDeleteValid() ? 'opacity-50 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600'}
          >
            Delete Save-Up
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
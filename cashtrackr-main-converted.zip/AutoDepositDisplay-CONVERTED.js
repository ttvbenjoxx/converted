/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/save-ups/AutoDepositDisplay.tsx */

import { useStore } from "@/lib/store";

export const AutoDepositDisplay = () => {
  const { saveUps } = useStore();

  const totalAutoDeposit = saveUps
    .filter(item => item.autoDeposit.enabled)
    .reduce((total, item) => total + item.autoDeposit.amount, 0);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="text-muted-foreground">
      Total Auto-Deposit: {formatCurrency(totalAutoDeposit)} per paycheck
    </div>
  );
};
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/cards/BalancesCard.tsx */

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";
import { useStore } from "@/lib/store";

interface BalancesCardProps {
  onHistoryClick: () => void;
}

export const BalancesCard = ({ onHistoryClick }: BalancesCardProps) => {
  const { balances } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Card className="bg-card border-border p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-foreground">Balances</h3>
        <Button 
          variant="ghost" 
          size="icon"
          onClick={onHistoryClick}
          className="text-foreground"
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-3">
        {Object.entries(balances).map(([key, value]) => (
          key !== 'atb' && (
            <div key={key} className="flex justify-between items-center">
              <span className="capitalize text-foreground">{key}</span>
              <span className="font-medium text-foreground">{formatCurrency(value)}</span>
            </div>
          )
        ))}
      </div>
    </Card>
  );
};
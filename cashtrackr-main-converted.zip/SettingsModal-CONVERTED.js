/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/SettingsModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { ChevronRight } from "lucide-react";
import { ATBModal } from "./settings/ATBModal";
import { CalculationsModal } from "./settings/CalculationsModal";
import { ResetConfirmationModal } from "./settings/ResetConfirmationModal";
import { toast } from "sonner";

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const [showATBModal, setShowATBModal] = useState(false);
  const [showCalculationsModal, setShowCalculationsModal] = useState(false);
  const [showOtherSettingsModal, setShowOtherSettingsModal] = useState(false);
  const [showResetConfirmation, setShowResetConfirmation] = useState(false);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="bg-card">
          <DialogHeader>
            <DialogTitle className="text-white">Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full justify-between text-white hover:text-white"
              onClick={() => setShowATBModal(true)}
            >
              ATB Edit <ChevronRight className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-between text-white hover:text-white"
              onClick={() => setShowCalculationsModal(true)}
            >
              Calculations <ChevronRight className="h-4 w-4" />
            </Button>
            <Button 
              variant="destructive" 
              className="w-full"
              onClick={() => setShowResetConfirmation(true)}
            >
              Reset All Data
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <ATBModal 
        open={showATBModal} 
        onOpenChange={setShowATBModal}
      />

      <CalculationsModal
        open={showCalculationsModal}
        onOpenChange={setShowCalculationsModal}
      />

      <ResetConfirmationModal
        open={showResetConfirmation}
        onOpenChange={setShowResetConfirmation}
        onComplete={() => onOpenChange(false)}
      />
    </>
  );
}
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/save-ups/SaveUpCard.tsx */

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Info, PiggyBank, Pencil, Trash2 } from "lucide-react";
import { SaveUpItem } from "@/lib/types";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { DeleteSaveUpModal } from "@/components/modals/DeleteSaveUpModal";

interface SaveUpCardProps {
  saveUp: SaveUpItem;
}

export const SaveUpCard = ({ saveUp }: SaveUpCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDepositExpanded, setIsDepositExpanded] = useState(false);
  const [depositAmount, setDepositAmount] = useState("");
  const [depositDetails, setDepositDetails] = useState("");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const { addDeposit, updateBalances, balances } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleExternalLink = () => {
    let url = saveUp.link;
    if (url && !url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    window.open(url, '_blank');
  };

  const handleDeposit = () => {
    const amount = Number(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    if (amount > balances.misc) {
      toast.error("Insufficient funds in spending money");
      return;
    }

    addDeposit(saveUp.id, amount, depositDetails);
    updateBalances({
      ...balances,
      misc: balances.misc - amount
    });
    
    setDepositAmount("");
    setDepositDetails("");
    setIsDepositExpanded(false);
    toast.success(`Added ${formatCurrency(amount)} to ${saveUp.name}`);
  };

  const remaining = saveUp.price - saveUp.saved;

  return (
    <div className="flex gap-4 w-full">
      <Card className="flex-grow bg-[#1A1F2C] border-border p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">{saveUp.name}</h3>
            <p className="text-3xl font-bold text-[#9b87f5]">{formatCurrency(saveUp.price)}</p>
          </div>
          <div className="flex gap-2">
            {saveUp.link && (
              <Button
                variant="outline"
                size="icon"
                onClick={handleExternalLink}
                className="text-white hover:bg-[#7E69AB] border-white/20"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            )}
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                setIsExpanded(!isExpanded);
                setIsDepositExpanded(false);
              }}
              className="text-white hover:bg-[#7E69AB] border-white/20"
            >
              <Info className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                setIsDepositExpanded(!isDepositExpanded);
                setIsExpanded(false);
              }}
              className="text-white hover:bg-[#7E69AB] border-white/20"
            >
              <PiggyBank className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {isExpanded && (
          <div className="mt-4 space-y-4 text-sm text-white">
            {saveUp.autoDeposit.enabled && (
              <p>Auto-Deposit: {formatCurrency(saveUp.autoDeposit.amount)} per paycheck</p>
            )}
            {saveUp.link && (
              <p>Link: <a href={saveUp.link} target="_blank" rel="noopener noreferrer" className="text-[#9b87f5] hover:underline">{saveUp.link}</a></p>
            )}
            {saveUp.details && <p>Details: {saveUp.details}</p>}
            {saveUp.deposits.length > 0 && (
              <div>
                <p className="font-semibold">Last Deposit:</p>
                <p>
                  {formatCurrency(saveUp.deposits[0].amount)} on{' '}
                  {formatDate(saveUp.deposits[0].date)}
                </p>
              </div>
            )}
            <div className="flex gap-2 mt-4">
              <Button
                variant="outline"
                size="sm"
                className="text-white hover:bg-[#7E69AB] border-white/20"
                onClick={() => toast.info("Edit functionality coming soon")}
              >
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-white hover:bg-red-900 border-white/20"
                onClick={() => setDeleteModalOpen(true)}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </div>
          </div>
        )}

        {isDepositExpanded && (
          <div className="mt-4 space-y-4">
            <div>
              <label className="text-sm text-gray-400">Amount</label>
              <Input
                type="number"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="Enter deposit amount"
                className="dark-input mt-1"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400">Details (optional)</label>
              <Textarea
                value={depositDetails}
                onChange={(e) => setDepositDetails(e.target.value)}
                placeholder="Enter deposit details"
                className="dark-input mt-1"
              />
            </div>
            <Button
              onClick={handleDeposit}
              className="w-full"
            >
              Add Deposit
            </Button>
          </div>
        )}
      </Card>

      <Card className="w-48 bg-[#1A1F2C] border-border p-4">
        <div className="space-y-2">
          <div>
            <p className="text-sm text-gray-400">Saved</p>
            <p className="text-lg font-bold text-[#4ade80]">{formatCurrency(saveUp.saved)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Remaining</p>
            <p className="text-lg font-bold text-[#ef4444]">{formatCurrency(remaining)}</p>
          </div>
        </div>
      </Card>

      <DeleteSaveUpModal
        open={deleteModalOpen}
        onOpenChange={setDeleteModalOpen}
        saveUp={saveUp}
      />
    </div>
  );
};
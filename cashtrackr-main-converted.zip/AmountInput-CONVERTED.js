/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/TransactionModal/AmountInput.tsx */

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Minus, Plus } from "lucide-react";

interface AmountInputProps {
  amount: string;
  setAmount: (value: string) => void;
  isPositive: boolean;
  setIsPositive: (value: boolean) => void;
}

export function AmountInput({ amount, setAmount, isPositive, setIsPositive }: AmountInputProps) {
  return (
    <div className="space-y-2">
      <Label className="text-white">Amount</Label>
      <div className="flex gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="outline" 
              size="icon" 
              className="w-10 bg-background hover:bg-accent"
            >
              {isPositive ? <Plus className="h-4 w-4 text-white" /> : <Minus className="h-4 w-4 text-white" />}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-[200px] bg-card border-border">
            <DropdownMenuItem onClick={() => setIsPositive(false)} className="text-white hover:bg-accent">
              <Minus className="h-4 w-4 mr-2" /> Subtract
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setIsPositive(true)} className="text-white hover:bg-accent">
              <Plus className="h-4 w-4 mr-2" /> Add
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <Input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter amount"
          className="flex-1 text-white bg-card"
        />
      </div>
    </div>
  );
}
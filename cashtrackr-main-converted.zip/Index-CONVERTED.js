/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/pages/Index.tsx */

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Wallet, Settings, DollarSign, ArrowUp } from "lucide-react";
import { useStore } from "@/lib/store";
import { TransactionModal } from "@/components/modals/TransactionModal";
import { PaydayModal } from "@/components/modals/PaydayModal";
import { SettingsModal } from "@/components/modals/SettingsModal";
import { useNavigate } from "react-router-dom";
import { PaycheckHistoryModal } from "@/components/modals/PaycheckHistoryModal";
import { ReimbursementDetailsModal } from "@/components/modals/ReimbursementDetailsModal";
import { BalancesCard } from "@/components/cards/BalancesCard";
import { SpendingMoneyCard } from "@/components/cards/SpendingMoneyCard";
import { NewTransactionCard } from "@/components/cards/NewTransactionCard";
import { ReimbursementCard } from "@/components/cards/ReimbursementCard";
import { RecentTransactionsCard } from "@/components/cards/RecentTransactionsCard";
import { MenuButton } from "@/components/navigation/MenuButton";

const Index = () => {
  const { balances } = useStore();
  const [transactionModalOpen, setTransactionModalOpen] = useState(false);
  const [paydayModalOpen, setPaydayModalOpen] = useState(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [paycheckHistoryModalOpen, setPaycheckHistoryModalOpen] = useState(false);
  const [selectedReimbursement, setSelectedReimbursement] = useState<any>(null);
  const [reimbursementDetailsModalOpen, setReimbursementDetailsModalOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 animate-fade-in">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl md:text-4xl font-bold text-foreground">Welcome Back!</h1>
        <div className="relative flex items-center">
          <MenuButton isOpen={isMenuOpen} onClick={toggleMenu} />
          
          <div className={`absolute right-full mr-2 flex gap-2 transition-all duration-300 ${
            isMenuOpen 
              ? 'opacity-100 translate-x-0' 
              : 'opacity-0 translate-x-10 pointer-events-none'
          }`}>
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate("/save-ups")}
              className="text-foreground transition-all duration-300 relative group"
            >
              <div className="relative flex items-center">
                <DollarSign className="h-5 w-5" />
                <ArrowUp className="h-4 w-4 ml-[-8px]" />
              </div>
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate("/transactions")}
              className="text-foreground transition-all duration-300"
            >
              <FileText className="h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setPaydayModalOpen(true)}
              className="text-foreground transition-all duration-300"
            >
              <Wallet className="h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSettingsModalOpen(true)}
              className="text-foreground transition-all duration-300"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Balance Card */}
      <Card className="mb-8 bg-card border-border">
        <div className="text-center p-6">
          <h2 className="text-foreground mb-2">Account Total Balance (ATB)</h2>
          <p className="text-4xl md:text-6xl font-bold text-primary">
            {formatCurrency(balances.atb)}
          </p>
        </div>
      </Card>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <BalancesCard onHistoryClick={() => setPaycheckHistoryModalOpen(true)} />
        <SpendingMoneyCard />
        <NewTransactionCard onNewTransaction={() => setTransactionModalOpen(true)} />
        <ReimbursementCard 
          onReimbursementClick={(reimbursement) => {
            setSelectedReimbursement(reimbursement);
            setReimbursementDetailsModalOpen(true);
          }} 
        />
        <RecentTransactionsCard />
      </div>

      {/* Modals */}
      <TransactionModal
        open={transactionModalOpen}
        onOpenChange={setTransactionModalOpen}
      />
      <PaydayModal
        open={paydayModalOpen}
        onOpenChange={setPaydayModalOpen}
      />
      <SettingsModal
        open={settingsModalOpen}
        onOpenChange={setSettingsModalOpen}
      />
      <PaycheckHistoryModal
        open={paycheckHistoryModalOpen}
        onOpenChange={setPaycheckHistoryModalOpen}
      />
      {selectedReimbursement && (
        <ReimbursementDetailsModal
          open={reimbursementDetailsModalOpen}
          onOpenChange={setReimbursementDetailsModalOpen}
          reimbursement={selectedReimbursement}
        />
      )}
    </div>
  );
};

export default Index;

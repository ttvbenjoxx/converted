/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/TransactionModal/RadioOptions.tsx */

import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface RadioOptionsProps {
  category: "misc" | "gas" | "reimbursement";
  setCategory: (value: "misc" | "gas" | "reimbursement") => void;
  isPositive: boolean;
}

export function RadioOptions({ category, setCategory, isPositive }: RadioOptionsProps) {
  return (
    <div className="space-y-2">
      <Label className="text-white">Category</Label>
      <RadioGroup value={category} onValueChange={(value: "misc" | "gas" | "reimbursement") => setCategory(value)}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="misc" id="misc" />
          <Label htmlFor="misc" className="text-white">Miscellaneous</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="gas" id="gas" />
          <Label htmlFor="gas" className="text-white">Gas</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="reimbursement" id="reimbursement" />
          <Label htmlFor="reimbursement" className="text-white">
            {isPositive ? "Money You Owe" : "Reimbursement"}
          </Label>
        </div>
      </RadioGroup>
    </div>
  );
}
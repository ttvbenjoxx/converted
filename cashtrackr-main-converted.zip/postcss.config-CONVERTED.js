/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/postcss.config.js */

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}

/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/settings/ResetConfirmationModal.tsx */

import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";

interface ResetConfirmationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onComplete: () => void;
}

export function ResetConfirmationModal({ open, onOpenChange, onComplete }: ResetConfirmationModalProps) {
  const { balances, resetAll } = useStore();
  const [resetText, setResetText] = useState("");
  const [currentATB, setCurrentATB] = useState("");
  const [confirmReset, setConfirmReset] = useState(false);

  const isResetValid = () => {
    return resetText === "Reset" && 
           currentATB === balances.atb.toString() && 
           confirmReset;
  };

  const handleReset = () => {
    if (!isResetValid()) {
      toast.error("Please fill in all fields correctly");
      return;
    }
    resetAll();
    onOpenChange(false);
    onComplete();
    toast.success("All data has been reset");
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-card">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-white">Reset All Data</AlertDialogTitle>
          <AlertDialogDescription className="text-gray-300">
            This action is irreversible. Please type "Reset" to confirm.
            <Input
              value={resetText}
              onChange={(e) => setResetText(e.target.value)}
              className="mt-2 dark-input"
              placeholder="Type 'Reset'"
            />
            <div className="mt-4">
              <Label className="text-white">Current ATB Amount: {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
              }).format(balances.atb)}</Label>
              <Input
                type="text"
                value={currentATB}
                onChange={(e) => setCurrentATB(e.target.value)}
                className="mt-2 dark-input"
                placeholder="Enter current ATB amount"
              />
            </div>
            <div className="flex items-center space-x-2 mt-4">
              <Checkbox
                id="confirm-reset"
                checked={confirmReset}
                onCheckedChange={(checked) => setConfirmReset(checked as boolean)}
              />
              <label
                htmlFor="confirm-reset"
                className="text-white text-sm font-medium leading-none"
              >
                I understand that this will delete all my data
              </label>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="text-white">Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={handleReset}
            disabled={!isResetValid()}
            className={!isResetValid() ? 'opacity-50 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600'}
          >
            Reset All Data
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/TransactionModal/ReimbursementFields.tsx */

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface ReimbursementFieldsProps {
  reimburser: string;
  setReimburser: (value: string) => void;
  reason: string;
  setReason: (value: string) => void;
  isPositive: boolean;
}

export function ReimbursementFields({ reimburser, setReimburser, reason, setReason, isPositive }: ReimbursementFieldsProps) {
  return (
    <>
      <div className="space-y-2">
        <Label className="text-white">{isPositive ? "Who You Owe" : "Reimburser Name"}</Label>
        <Input
          value={reimburser}
          onChange={(e) => setReimburser(e.target.value)}
          placeholder={isPositive ? "Enter who you owe" : "Enter reimburser name"}
          className="text-white bg-card"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-white">Reason</Label>
        <Input
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Enter reason"
          className="text-white bg-card"
        />
      </div>
    </>
  );
}
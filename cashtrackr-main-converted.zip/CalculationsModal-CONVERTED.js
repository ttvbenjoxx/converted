/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/settings/CalculationsModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";

interface CalculationsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CalculationsModal({ open, onOpenChange }: CalculationsModalProps) {
  const { calculations, updateCalculations } = useStore();
  const [localCalculations, setLocalCalculations] = useState(calculations);

  const handleCalculationsSave = () => {
    updateCalculations(localCalculations);
    onOpenChange(false);
    toast.success("Calculations updated successfully");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card">
        <DialogHeader>
          <DialogTitle className="text-white">Calculations</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-white">Hourly Rate ($)</Label>
            <Input
              type="number"
              value={localCalculations.hourlyRate}
              onChange={(e) =>
                setLocalCalculations({
                  ...localCalculations,
                  hourlyRate: Number(e.target.value),
                })
              }
              className="dark-input"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-white">Savings Percentage</Label>
            <Input
              type="number"
              value={localCalculations.savingsPercentage}
              onChange={(e) =>
                setLocalCalculations({
                  ...localCalculations,
                  savingsPercentage: Number(e.target.value),
                })
              }
              className="dark-input"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-white">Fixed Gas Amount</Label>
            <Input
              type="number"
              value={localCalculations.gasFixed}
              onChange={(e) =>
                setLocalCalculations({
                  ...localCalculations,
                  gasFixed: Number(e.target.value),
                })
              }
              className="dark-input"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-white">Fixed Insurance Amount</Label>
            <Input
              type="number"
              value={localCalculations.insuranceFixed}
              onChange={(e) =>
                setLocalCalculations({
                  ...localCalculations,
                  insuranceFixed: Number(e.target.value),
                })
              }
              className="dark-input"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)} className="text-white">Cancel</Button>
            <Button onClick={handleCalculationsSave}>Save Changes</Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
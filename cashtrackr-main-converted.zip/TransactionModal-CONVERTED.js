/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/TransactionModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Minus, Plus } from "lucide-react";

interface TransactionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TransactionModal({ open, onOpenChange }: TransactionModalProps) {
  const { addTransaction, addReimbursement, balances, updateBalances } = useStore();
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<"misc" | "gas" | "reimbursement">("misc");
  const [reimburser, setReimburser] = useState("");
  const [reason, setReason] = useState("");
  const [isPositive, setIsPositive] = useState(false);

  const handleSubmit = () => {
    console.log("Submitting transaction...");
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    const finalAmount = isPositive ? numAmount : -numAmount;

    try {
      if (category === "reimbursement") {
        console.log("Processing reimbursement transaction...");
        if (!reimburser || !reason) {
          toast.error("Please fill in all reimbursement details");
          return;
        }

        // Add to reimbursements
        addReimbursement({
          amount: Math.abs(finalAmount),
          reimburser: isPositive ? "You owe" : reimburser,
          reason: isPositive ? `You owe ${reimburser}: ${reason}` : reason
        });

        // Update balances for money owed
        if (isPositive) {
          updateBalances({
            misc: balances.misc + finalAmount,
            atb: balances.atb + finalAmount
          });
        } else {
          updateBalances({
            misc: balances.misc + finalAmount,
            atb: balances.atb + finalAmount
          });
        }

        // Add transaction
        addTransaction({
          amount: finalAmount,
          description: isPositive ? `You owe ${reimburser}: ${reason}` : `Reimbursement from ${reimburser}: ${reason}`,
          category: "reimbursement"
        });

        console.log("Reimbursement processed successfully");
      } else if (category === "gas") {
        console.log("Processing gas transaction...");
        if (Math.abs(finalAmount) > balances.gas && !isPositive) {
          const fromMisc = Math.abs(finalAmount) - balances.gas;
          updateBalances({
            gas: 0,
            misc: balances.misc - fromMisc,
            atb: balances.atb + finalAmount,
          });
        } else {
          updateBalances({
            gas: balances.gas + finalAmount,
            atb: balances.atb + finalAmount,
          });
        }

        addTransaction({
          amount: finalAmount,
          description,
          category: "gas"
        });
      } else {
        console.log("Processing misc transaction...");
        updateBalances({
          misc: balances.misc + finalAmount,
          atb: balances.atb + finalAmount,
        });

        addTransaction({
          amount: finalAmount,
          description,
          category: "misc"
        });
      }

      toast.success("Transaction added successfully");
      onOpenChange(false);
      setAmount("");
      setDescription("");
      setCategory("misc");
      setReimburser("");
      setReason("");
      setIsPositive(false);
    } catch (error) {
      console.error("Error processing transaction:", error);
      toast.error("Failed to process transaction");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Transaction</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Amount</Label>
            <div className="flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="w-10 bg-background hover:bg-accent"
                  >
                    {isPositive ? <Plus className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-[200px]">
                  <DropdownMenuItem onClick={() => setIsPositive(false)}>
                    <Minus className="h-4 w-4 mr-2" /> Subtract
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setIsPositive(true)}>
                    <Plus className="h-4 w-4 mr-2" /> Add
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="flex-1"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter description"
            />
          </div>
          <div className="space-y-2">
            <Label>Category</Label>
            <RadioGroup value={category} onValueChange={(value: "misc" | "gas" | "reimbursement") => setCategory(value)}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="misc" id="misc" />
                <Label htmlFor="misc">Miscellaneous</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="gas" id="gas" />
                <Label htmlFor="gas">Gas</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="reimbursement" id="reimbursement" />
                <Label htmlFor="reimbursement">
                  {isPositive ? "Money You Owe" : "Reimbursement"}
                </Label>
              </div>
            </RadioGroup>
          </div>
          {category === "reimbursement" && (
            <>
              <div className="space-y-2">
                <Label>{isPositive ? "Who You Owe" : "Reimburser Name"}</Label>
                <Input
                  value={reimburser}
                  onChange={(e) => setReimburser(e.target.value)}
                  placeholder={isPositive ? "Enter who you owe" : "Enter reimburser name"}
                />
              </div>
              <div className="space-y-2">
                <Label>Reason</Label>
                <Input
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Enter reason"
                />
              </div>
            </>
          )}
        </div>
        <Button onClick={handleSubmit} className="w-full">
          Add Transaction
        </Button>
      </DialogContent>
    </Dialog>
  );
}
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/lib/store/initialState.ts */

export const initialState = {
  balances: {
    atb: 0,
    gas: 0,
    insurance: 0,
    savings: 0,
    misc: 0,
  },
  transactions: [],
  reimbursements: [],
  paychecks: [],
  calculations: {
    savingsPercentage: 50,
    gasFixed: 50,
    insuranceFixed: 65,
    hourlyRate: 15,
  },
  saveUps: [],
};
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/vite-env.d.ts */

/// <reference types="vite/client" />

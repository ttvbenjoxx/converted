/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/save-ups/SaveUpsList.tsx */

import { useStore } from "@/lib/store";
import { SaveUpCard } from "./SaveUpCard";

export const SaveUpsList = () => {
  const { saveUps } = useStore();

  if (saveUps.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-8">
        No save-ups yet. Add one to get started!
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6">
      {saveUps.map((saveUp) => (
        <SaveUpCard key={saveUp.id} saveUp={saveUp} />
      ))}
    </div>
  );
};
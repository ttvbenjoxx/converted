/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/cards/SpendingMoneyCard.tsx */

import { Card } from "@/components/ui/card";
import { useStore } from "@/lib/store";

export const SpendingMoneyCard = () => {
  const { balances } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Card className="bg-card border-border p-6">
      <h3 className="text-lg font-semibold mb-4 text-foreground">Spending Money</h3>
      <p className="spending-money">{formatCurrency(balances.misc)}</p>
    </Card>
  );
};
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/navigation/MenuButton.tsx */

import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

interface MenuButtonProps {
  isOpen: boolean;
  onClick: () => void;
}

export const MenuButton = ({ isOpen, onClick }: MenuButtonProps) => {
  return (
    <Button
      variant="outline"
      size="icon"
      onClick={onClick}
      className="relative z-50 transition-all duration-300"
    >
      {isOpen ? (
        <X className="h-5 w-5 transition-transform duration-300 rotate-0" />
      ) : (
        <Menu className="h-5 w-5" />
      )}
    </Button>
  );
};
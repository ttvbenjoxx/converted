/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/PaycheckHistoryModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Settings } from "lucide-react";
import { useState } from "react";
import { useStore } from "@/lib/store";

interface PaycheckHistoryModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PaycheckHistoryModal({ open, onOpenChange }: PaycheckHistoryModalProps) {
  const { calculations, paychecks } = useStore();
  const [showSettings, setShowSettings] = useState(false);
  const [selectedPaycheck, setSelectedPaycheck] = useState<string | null>(null);
  const [taxSettings, setTaxSettings] = useState({
    federal: 22,
    state: 5,
    county: 1,
    socialSecurity: 6.2,
    medicare: 1.45
  });

  const calculateGrossAmount = (netAmount: number) => {
    const totalTaxRate = (
      taxSettings.federal +
      taxSettings.state +
      taxSettings.county +
      taxSettings.socialSecurity +
      taxSettings.medicare
    ) / 100;
    return netAmount / (1 - totalTaxRate);
  };

  const calculateHoursWorked = (grossAmount: number) => {
    return Math.round((grossAmount / calculations.hourlyRate) * 100) / 100;
  };

  const calculateDeductions = (grossAmount: number) => {
    return {
      federal: (grossAmount * taxSettings.federal) / 100,
      state: (grossAmount * taxSettings.state) / 100,
      county: (grossAmount * taxSettings.county) / 100,
      socialSecurity: (grossAmount * taxSettings.socialSecurity) / 100,
      medicare: (grossAmount * taxSettings.medicare) / 100,
      savings: (grossAmount * calculations.savingsPercentage) / 100,
      gas: calculations.gasFixed,
      insurance: calculations.insuranceFixed
    };
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-white font-semibold">Paycheck History</DialogTitle>
            <Button variant="outline" size="icon" onClick={() => setShowSettings(!showSettings)}>
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        {showSettings ? (
          <div className="space-y-4">
            <h3 className="font-medium">Tax Settings</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Federal Tax (%)</Label>
                <Input
                  type="number"
                  value={taxSettings.federal}
                  onChange={(e) => setTaxSettings({
                    ...taxSettings,
                    federal: Number(e.target.value)
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>State Tax (%)</Label>
                <Input
                  type="number"
                  value={taxSettings.state}
                  onChange={(e) => setTaxSettings({
                    ...taxSettings,
                    state: Number(e.target.value)
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>County Tax (%)</Label>
                <Input
                  type="number"
                  value={taxSettings.county}
                  onChange={(e) => setTaxSettings({
                    ...taxSettings,
                    county: Number(e.target.value)
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>Social Security (%)</Label>
                <Input
                  type="number"
                  value={taxSettings.socialSecurity}
                  onChange={(e) => setTaxSettings({
                    ...taxSettings,
                    socialSecurity: Number(e.target.value)
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>Medicare (%)</Label>
                <Input
                  type="number"
                  value={taxSettings.medicare}
                  onChange={(e) => setTaxSettings({
                    ...taxSettings,
                    medicare: Number(e.target.value)
                  })}
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-4">
              {paychecks.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  No paychecks recorded yet
                </div>
              ) : (
                paychecks.map((paycheck) => {
                  const isSelected = selectedPaycheck === paycheck.id;
                  const grossAmount = calculateGrossAmount(paycheck.amount);
                  const hoursWorked = calculateHoursWorked(grossAmount);
                  const deductions = calculateDeductions(grossAmount);

                  return (
                    <div 
                      key={paycheck.id} 
                      className={`border rounded-lg p-4 space-y-2 cursor-pointer transition-colors ${
                        isSelected ? 'border-primary' : ''
                      }`}
                      onClick={() => setSelectedPaycheck(isSelected ? null : paycheck.id)}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Net Amount</span>
                        <span>{formatCurrency(paycheck.amount)}</span>
                      </div>
                      
                      {isSelected && (
                        <div className="mt-4 space-y-4 border-t pt-4">
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="font-medium">Gross Amount:</span>
                              <span>{formatCurrency(grossAmount)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="font-medium">Hours Worked:</span>
                              <span>{hoursWorked} hours (at {formatCurrency(calculations.hourlyRate)}/hr)</span>
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <h4 className="text-sm font-medium">Deductions:</h4>
                            <div className="text-sm space-y-1 text-muted-foreground">
                              <div className="flex justify-between">
                                <span>Federal Tax</span>
                                <span>{formatCurrency(deductions.federal)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>State Tax</span>
                                <span>{formatCurrency(deductions.state)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>County Tax</span>
                                <span>{formatCurrency(deductions.county)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Social Security</span>
                                <span>{formatCurrency(deductions.socialSecurity)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Medicare</span>
                                <span>{formatCurrency(deductions.medicare)}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      <div className="text-sm space-y-1 text-muted-foreground">
                        <div className="flex justify-between">
                          <span>Savings</span>
                          <span>{formatCurrency(paycheck.distributions.savings)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Gas</span>
                          <span>{formatCurrency(paycheck.distributions.gas)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Insurance</span>
                          <span>{formatCurrency(paycheck.distributions.insurance)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Miscellaneous</span>
                          <span>{formatCurrency(paycheck.distributions.misc)}</span>
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-2">
                        {new Date(paycheck.date).toLocaleDateString()}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
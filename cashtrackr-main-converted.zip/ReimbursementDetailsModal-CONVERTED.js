/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/ReimbursementDetailsModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ReimbursementDetailsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reimbursement: {
    id: string;
    amount: number;
    reimburser: string;
    reason: string;
    date: string;
    payments?: { amount: number; date: string }[];
    remainingBalance?: number;
  };
}

export function ReimbursementDetailsModal({ 
  open, 
  onOpenChange, 
  reimbursement 
}: ReimbursementDetailsModalProps) {
  const { balances, updateBalances, reimbursements, updateReimbursements, addTransaction } = useStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editedAmount, setEditedAmount] = useState(reimbursement.amount.toString());
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [actualPayment, setActualPayment] = useState("");

  const handleAmountClick = () => {
    setIsEditing(true);
  };

  const handleAmountSave = () => {
    const newAmount = Number(editedAmount);
    if (isNaN(newAmount) || newAmount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }
    
    const updatedReimbursements = reimbursements.map(r => {
      if (r.id === reimbursement.id) {
        return { ...r, amount: newAmount };
      }
      return r;
    });
    
    updateReimbursements(updatedReimbursements);
    setIsEditing(false);
    toast.success("Amount updated successfully");
  };

  const handleClose = () => {
    setShowCloseDialog(true);
  };

  const processPayment = () => {
    const payment = Number(actualPayment);
    if (isNaN(payment) || payment <= 0) {
      toast.error("Please enter a valid payment amount");
      return;
    }

    const originalAmount = reimbursement.amount;
    const currentDate = new Date().toISOString();

    if (payment < originalAmount) {
      // Partial payment
      const remainingBalance = originalAmount - payment;
      
      // Update balances
      updateBalances({
        misc: balances.misc + payment,
        atb: balances.atb + payment
      });

      // Update reimbursement with remaining balance and payment history
      const updatedReimbursements = reimbursements.map(r => {
        if (r.id === reimbursement.id) {
          return {
            ...r,
            amount: remainingBalance,
            payments: [...(r.payments || []), { amount: payment, date: currentDate }],
            remainingBalance
          };
        }
        return r;
      });
      
      updateReimbursements(updatedReimbursements);
      toast.success(`Partial payment of ${payment} received. Remaining balance: ${remainingBalance}`);
    } else {
      // Full payment or overpayment
      updateBalances({
        misc: balances.misc + payment,
        atb: balances.atb + payment
      });

      // Add as official transaction for full payments
      addTransaction({
        amount: payment,
        description: `Reimbursement from ${reimbursement.reimburser}: ${reimbursement.reason}`,
        category: "reimbursement"
      });

      // Remove the reimbursement from the list
      const updatedReimbursements = reimbursements.filter(r => r.id !== reimbursement.id);
      updateReimbursements(updatedReimbursements);

      if (payment > originalAmount) {
        toast.success(`Reimbursement closed with additional amount of ${payment - originalAmount}`);
      } else {
        toast.success("Reimbursement closed successfully");
      }
    }

    setShowCloseDialog(false);
    onOpenChange(false);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reimbursement Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Amount</Label>
              {isEditing ? (
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={editedAmount}
                    onChange={(e) => setEditedAmount(e.target.value)}
                  />
                  <Button onClick={handleAmountSave}>Save</Button>
                </div>
              ) : (
                <p 
                  className="text-xl font-bold cursor-pointer hover:text-primary"
                  onClick={handleAmountClick}
                >
                  {new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD'
                  }).format(reimbursement.amount)}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>From</Label>
              <p>{reimbursement.reimburser}</p>
            </div>
            <div className="space-y-2">
              <Label>Reason</Label>
              <p>{reimbursement.reason}</p>
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <p>{new Date(reimbursement.date).toLocaleDateString()}</p>
            </div>
            {reimbursement.payments && reimbursement.payments.length > 0 && (
              <div className="space-y-2">
                <Label>Payment History</Label>
                <ScrollArea className="h-[100px] rounded-md border p-2">
                  <div className="space-y-1">
                    {reimbursement.payments.map((payment, index) => (
                      <div key={index} className="text-sm text-muted-foreground">
                        {new Intl.NumberFormat('en-US', {
                          style: 'currency',
                          currency: 'USD'
                        }).format(payment.amount)} on {new Date(payment.date).toLocaleDateString()}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                {reimbursement.remainingBalance && reimbursement.remainingBalance > 0 && (
                  <p className="text-sm font-medium text-destructive">
                    Remaining Balance: {new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: 'USD'
                    }).format(reimbursement.remainingBalance)}
                  </p>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button onClick={handleClose}>Close Reimbursement</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showCloseDialog} onOpenChange={setShowCloseDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Close Reimbursement</AlertDialogTitle>
            <AlertDialogDescription>
              Expected amount: {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
              }).format(reimbursement.amount)}
              <div className="mt-4">
                <Label>Enter actual payment received</Label>
                <Input
                  type="number"
                  value={actualPayment}
                  onChange={(e) => setActualPayment(e.target.value)}
                  className="mt-2"
                />
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={processPayment}>Process Payment</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
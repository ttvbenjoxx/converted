/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/TransactionPDFModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useStore } from "@/lib/store";
import { Link } from "react-router-dom";

interface TransactionPDFModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TransactionPDFModal({ open, onOpenChange }: TransactionPDFModalProps) {
  const { transactions } = useStore();
  
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const recentTransactions = transactions.filter(t => new Date(t.date) >= thirtyDaysAgo);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Transaction History</DialogTitle>
        </DialogHeader>
        
        <style type="text/css" media="print">
          {`
            @page {
              size: auto;
              margin: 20mm;
            }
            @media print {
              body * {
                visibility: hidden;
              }
              #printable-content, #printable-content * {
                visibility: visible;
              }
              #printable-content {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
              }
              .no-print {
                display: none !important;
              }
            }
          `}
        </style>

        <div id="printable-content" className="flex-1">
          {recentTransactions.length === 0 ? (
            <div className="text-center space-y-4 py-8">
              <p className="text-muted-foreground">
                No Transactions Available. {' '}
                <Link 
                  to="/?newTransaction=true" 
                  className="text-primary hover:underline"
                  onClick={() => onOpenChange(false)}
                >
                  Start a new Transaction
                </Link>
              </p>
              <p className="text-muted-foreground">
                Got Paid? {' '}
                <Link 
                  to="/?newPayday=true" 
                  className="text-primary hover:underline"
                  onClick={() => onOpenChange(false)}
                >
                  Add a new Payday
                </Link>
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex justify-between items-center py-3 border-b border-gray-200">
                  <div>
                    <p className="font-medium">{transaction.description}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(transaction.date).toLocaleString()}
                    </p>
                  </div>
                  <p className={transaction.amount >= 0 ? "text-green-500" : "text-red-500"}>
                    {transaction.amount >= 0 ? '+' : ''}
                    {new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: 'USD'
                    }).format(transaction.amount)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
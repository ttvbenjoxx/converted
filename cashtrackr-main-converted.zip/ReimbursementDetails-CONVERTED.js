/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/ReimbursementDetailsModal/ReimbursementDetails.tsx */

import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface ReimbursementDetailsProps {
  amount: number;
  reimburser: string;
  reason: string;
  date: string;
  onAmountSave: (amount: number) => void;
}

export function ReimbursementDetails({ 
  amount, 
  reimburser, 
  reason, 
  date,
  onAmountSave 
}: ReimbursementDetailsProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedAmount, setEditedAmount] = useState(amount.toString());

  const handleAmountSave = () => {
    onAmountSave(Number(editedAmount));
    setIsEditing(false);
  };

  return (
    <div className="space-y-4 bg-card p-4 rounded-lg border border-border">
      <div className="space-y-2">
        <Label className="text-white">Amount</Label>
        {isEditing ? (
          <div className="flex gap-2">
            <Input
              type="number"
              value={editedAmount}
              onChange={(e) => setEditedAmount(e.target.value)}
              className="text-white bg-card"
            />
            <Button onClick={handleAmountSave} className="bg-primary text-white">Save</Button>
          </div>
        ) : (
          <p 
            className="text-xl font-bold cursor-pointer hover:text-primary text-white"
            onClick={() => setIsEditing(true)}
          >
            {new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD'
            }).format(amount)}
          </p>
        )}
      </div>
      <div className="space-y-2">
        <Label className="text-white">From</Label>
        <p className="text-white">{reimburser}</p>
      </div>
      <div className="space-y-2">
        <Label className="text-white">Reason</Label>
        <p className="text-white">{reason}</p>
      </div>
      <div className="space-y-2">
        <Label className="text-white">Date</Label>
        <p className="text-white">{new Date(date).toLocaleDateString()}</p>
      </div>
    </div>
  );
}
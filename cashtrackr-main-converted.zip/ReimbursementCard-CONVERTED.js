/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/cards/ReimbursementCard.tsx */

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";

interface ReimbursementCardProps {
  onReimbursementClick: (reimbursement: any) => void;
}

export const ReimbursementCard = ({ onReimbursementClick }: ReimbursementCardProps) => {
  const { reimbursements } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Card className="bg-card border-border p-6">
      <h3 className="text-lg font-semibold mb-4 text-foreground">Reimbursement</h3>
      {reimbursements.length === 0 ? (
        <p className="text-muted-foreground">No pending reimbursements</p>
      ) : (
        <div className="space-y-4">
          {reimbursements.map((reimbursement) => (
            <Button
              key={reimbursement.id}
              variant="outline"
              className="w-full text-left flex justify-between items-center text-foreground"
              onClick={() => onReimbursementClick(reimbursement)}
            >
              <span>{reimbursement.reimburser}</span>
              <span>{formatCurrency(reimbursement.amount)}</span>
            </Button>
          ))}
        </div>
      )}
    </Card>
  );
};
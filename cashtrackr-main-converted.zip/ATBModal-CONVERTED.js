/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/settings/ATBModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";

interface ATBModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ATBModal({ open, onOpenChange }: ATBModalProps) {
  const { balances, updateBalances } = useStore();
  const [newATB, setNewATB] = useState(balances.atb.toString());

  const handleATBUpdate = () => {
    const numATB = Number(newATB);
    if (isNaN(numATB)) {
      toast.error("Please enter a valid amount");
      return;
    }
    updateBalances({ ...balances, atb: numATB });
    onOpenChange(false);
    toast.success("ATB updated successfully");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card">
        <DialogHeader>
          <DialogTitle className="text-white">Edit ATB</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-white">Account Total Balance (ATB)</Label>
            <Input
              type="number"
              value={newATB}
              onChange={(e) => setNewATB(e.target.value)}
              className="dark-input"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)} className="text-white">Cancel</Button>
            <Button onClick={handleATBUpdate}>Save Changes</Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
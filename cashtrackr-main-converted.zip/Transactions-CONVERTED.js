/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/pages/Transactions.tsx */

import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { Home, Printer } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Transactions = () => {
  const { transactions } = useStore();
  const navigate = useNavigate();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const handlePrint = () => {
    window.print();
  };

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const recentTransactions = transactions.filter(t => new Date(t.date) >= thirtyDaysAgo);

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl md:text-4xl font-bold text-white">Transactions</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={handlePrint} className="text-white">
            <Printer className="h-5 w-5" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => navigate("/")} className="text-white">
            <Home className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <div id="printable-content">
        <div className="space-y-4">
          {recentTransactions.length === 0 ? (
            <div className="text-center space-y-4 py-8">
              <p className="text-white">No Transactions Available</p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div 
                  key={transaction.id} 
                  className="flex justify-between items-center py-3 border-b border-border bg-card rounded-lg p-4"
                >
                  <div>
                    <p className="font-medium text-white">{transaction.description}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(transaction.date).toLocaleString()}
                    </p>
                  </div>
                  <p className={`text-base font-semibold ${
                    transaction.amount >= 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {transaction.amount >= 0 ? '+' : ''}
                    {formatCurrency(transaction.amount)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Transactions;
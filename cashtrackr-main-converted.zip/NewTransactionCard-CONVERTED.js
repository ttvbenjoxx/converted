/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/cards/NewTransactionCard.tsx */

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface NewTransactionCardProps {
  onNewTransaction: () => void;
}

export const NewTransactionCard = ({ onNewTransaction }: NewTransactionCardProps) => {
  return (
    <Card className="bg-card border-border p-6">
      <h3 className="text-lg font-semibold mb-4 text-foreground">New Transaction</h3>
      <Button className="w-full bg-primary text-primary-foreground" onClick={onNewTransaction}>
        <Plus className="mr-2 h-4 w-4" /> New Transaction
      </Button>
    </Card>
  );
};
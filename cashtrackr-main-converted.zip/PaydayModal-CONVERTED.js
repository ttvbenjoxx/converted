/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/modals/PaydayModal.tsx */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { useState } from "react";
import { toast } from "sonner";

interface PaydayModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PaydayModal({ open, onOpenChange }: PaydayModalProps) {
  const { calculations, balances, updateBalances, addTransaction, addPaycheck } = useStore();
  const [amount, setAmount] = useState("");

  const handlePayday = () => {
    const paydayAmount = Number(amount);
    if (isNaN(paydayAmount) || paydayAmount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    const savingsAmount = (paydayAmount * calculations.savingsPercentage) / 100;
    const gasAmount = calculations.gasFixed;
    const insuranceAmount = calculations.insuranceFixed;
    const miscAmount = paydayAmount - savingsAmount - gasAmount - insuranceAmount;

    updateBalances({
      atb: balances.atb + paydayAmount,
      savings: balances.savings + savingsAmount,
      gas: balances.gas + gasAmount,
      insurance: balances.insurance + insuranceAmount,
      misc: balances.misc + miscAmount,
    });

    addTransaction({
      amount: paydayAmount,
      description: "Payday",
      category: "misc",
    });

    // Add to paycheck history
    addPaycheck({
      amount: paydayAmount,
      distributions: {
        savings: savingsAmount,
        gas: gasAmount,
        insurance: insuranceAmount,
        misc: miscAmount,
      },
    });

    toast.success("Payday processed successfully");
    onOpenChange(false);
    setAmount("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-white font-semibold">New Payday</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Amount</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter payday amount"
            />
          </div>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>Current Calculations:</p>
            <p>Savings: {calculations.savingsPercentage}%</p>
            <p>Gas: ${calculations.gasFixed}</p>
            <p>Insurance: ${calculations.insuranceFixed}</p>
          </div>
        </div>
        <Button onClick={handlePayday} className="w-full">
          Process Payday
        </Button>
      </DialogContent>
    </Dialog>
  );
}
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/lib/store.ts */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Balances, Transaction, Reimbursement, Calculations, Paycheck, SaveUpItem } from './types';

interface Store {
  balances: Balances;
  transactions: Transaction[];
  reimbursements: Reimbursement[];
  paychecks: Paycheck[];
  calculations: Calculations;
  updateBalances: (newBalances: Partial<Balances>) => void;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
  addReimbursement: (reimbursement: Omit<Reimbursement, 'id' | 'date'>) => void;
  updateReimbursements: (reimbursements: Reimbursement[]) => void;
  addPaycheck: (paycheck: Omit<Paycheck, 'id' | 'date'>) => void;
  updateCalculations: (newCalculations: Partial<Calculations>) => void;
  resetAll: () => void;
  saveUps: SaveUpItem[];
  addSaveUp: (item: Omit<SaveUpItem, 'id' | 'saved' | 'deposits'>) => void;
  updateSaveUp: (id: string, updates: Partial<SaveUpItem>) => void;
  deleteSaveUp: (id: string) => void;
  addDeposit: (saveUpId: string, amount: number, details?: string) => void;
}

const initialState = {
  balances: {
    atb: 0,
    gas: 0,
    insurance: 0,
    savings: 0,
    misc: 0,
  },
  transactions: [],
  reimbursements: [],
  paychecks: [],
  calculations: {
    savingsPercentage: 50,
    gasFixed: 50,
    insuranceFixed: 65,
    hourlyRate: 15,
  },
  saveUps: [],
};

export const useStore = create<Store>()(
  persist(
    (set) => ({
      ...initialState,
      updateBalances: (newBalances) =>
        set((state) => ({
          balances: { ...state.balances, ...newBalances },
        })),
      addTransaction: (transaction) =>
        set((state) => ({
          transactions: [
            {
              ...transaction,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
            },
            ...state.transactions,
          ],
        })),
      addPaycheck: (paycheck) =>
        set((state) => ({
          paychecks: [
            {
              ...paycheck,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
            },
            ...state.paychecks,
          ],
        })),
      addReimbursement: (reimbursement) =>
        set((state) => ({
          reimbursements: [
            {
              ...reimbursement,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
            },
            ...state.reimbursements,
          ],
        })),
      updateReimbursements: (reimbursements) =>
        set(() => ({
          reimbursements,
        })),
      updateCalculations: (newCalculations) =>
        set((state) => ({
          calculations: { ...state.calculations, ...newCalculations },
        })),
      resetAll: () => set(initialState),
      saveUps: [],
      addSaveUp: (item) =>
        set((state) => ({
          saveUps: [
            ...state.saveUps,
            {
              ...item,
              id: crypto.randomUUID(),
              saved: 0,
              deposits: [],
            },
          ],
        })),
      updateSaveUp: (id, updates) =>
        set((state) => ({
          saveUps: state.saveUps.map((item) =>
            item.id === id ? { ...item, ...updates } : item
          ),
        })),
      deleteSaveUp: (id) =>
        set((state) => ({
          saveUps: state.saveUps.filter((item) => item.id !== id),
        })),
      addDeposit: (saveUpId, amount, details) =>
        set((state) => ({
          saveUps: state.saveUps.map((item) =>
            item.id === saveUpId
              ? {
                  ...item,
                  saved: item.saved + amount,
                  deposits: [
                    {
                      amount,
                      date: new Date().toISOString(),
                      details,
                    },
                    ...item.deposits,
                  ],
                }
              : item
          ),
        })),
    }),
    {
      name: 'money-mosaic-storage',
    }
  )
);
/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/lib/store/index.ts */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Store } from './types';
import { initialState } from './initialState';

export const useStore = create<Store>()(
  persist(
    (set) => ({
      ...initialState,
      updateBalances: (newBalances) =>
        set((state) => ({
          balances: { ...state.balances, ...newBalances },
        })),
      addTransaction: (transaction) =>
        set((state) => ({
          transactions: [
            {
              ...transaction,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
            },
            ...state.transactions,
          ],
        })),
      addPaycheck: (paycheck) =>
        set((state) => ({
          paychecks: [
            {
              ...paycheck,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
            },
            ...state.paychecks,
          ],
        })),
      addReimbursement: (reimbursement) =>
        set((state) => ({
          reimbursements: [
            {
              ...reimbursement,
              id: crypto.randomUUID(),
              date: new Date().toISOString(),
            },
            ...state.reimbursements,
          ],
        })),
      updateReimbursements: (reimbursements) =>
        set(() => ({
          reimbursements,
        })),
      updateCalculations: (newCalculations) =>
        set((state) => ({
          calculations: { ...state.calculations, ...newCalculations },
        })),
      resetAll: () => set(initialState),
      addSaveUp: (item) =>
        set((state) => ({
          saveUps: [
            ...state.saveUps,
            {
              ...item,
              id: crypto.randomUUID(),
              saved: 0,
              deposits: [],
            },
          ],
        })),
      updateSaveUp: (id, updates) =>
        set((state) => ({
          saveUps: state.saveUps.map((item) =>
            item.id === id ? { ...item, ...updates } : item
          ),
        })),
      deleteSaveUp: (id) =>
        set((state) => ({
          saveUps: state.saveUps.filter((item) => item.id !== id),
        })),
      addDeposit: (saveUpId, amount, details) =>
        set((state) => ({
          saveUps: state.saveUps.map((item) =>
            item.id === saveUpId
              ? {
                  ...item,
                  saved: item.saved + amount,
                  deposits: [
                    {
                      amount,
                      date: new Date().toISOString(),
                      details,
                    },
                    ...item.deposits,
                  ],
                }
              : item
          ),
        })),
    }),
    {
      name: 'money-mosaic-storage',
    }
  )
);
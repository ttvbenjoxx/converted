/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/ui/aspect-ratio.tsx */

import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio"

const AspectRatio = AspectRatioPrimitive.Root

export { AspectRatio }

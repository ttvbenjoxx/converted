/* Converted version of /mnt/data/cashtrackr-main/cashtrackr-main/src/components/cards/RecentTransactionsCard.tsx */

import { Card } from "@/components/ui/card";
import { useStore } from "@/lib/store";

export const RecentTransactionsCard = () => {
  const { transactions } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Card className="bg-card border-border p-6 md:col-span-2">
      <h3 className="text-lg font-semibold mb-4 text-foreground">Recent Transactions</h3>
      <div className="space-y-3">
        {transactions.slice(0, 6).map((transaction) => (
          <div key={transaction.id} className="flex justify-between items-center">
            <div>
              <p className="font-medium text-foreground">{transaction.description}</p>
              <p className="text-sm text-muted-foreground">
                {new Date(transaction.date).toLocaleDateString()}
              </p>
            </div>
            <p className={transaction.amount >= 0 ? "amount-positive" : "amount-negative"}>
              {formatCurrency(transaction.amount)}
            </p>
          </div>
        ))}
      </div>
    </Card>
  );
};